package com.gag.fraud.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

import java.math.BigDecimal;

public class TransactionRequest {

    @NotBlank
    private String transactionId;

    @NotBlank
    private String customerId;

    @NotNull
    @DecimalMin(value = "0.01")
    private BigDecimal amount;

    @NotBlank
    private String currency;

    @NotBlank
    private String country;

    @NotBlank
    private String deviceId;

    @NotBlank
    private String ipAddress;

    @NotNull
    @PositiveOrZero
    private Integer customerAccountAgeDays;

    @NotNull
    @PositiveOrZero
    private Integer transactionsLast24h;

    @NotNull
    @PositiveOrZero
    private Integer chargebacksLast90d;

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public Integer getCustomerAccountAgeDays() {
        return customerAccountAgeDays;
    }

    public void setCustomerAccountAgeDays(Integer customerAccountAgeDays) {
        this.customerAccountAgeDays = customerAccountAgeDays;
    }

    public Integer getTransactionsLast24h() {
        return transactionsLast24h;
    }

    public void setTransactionsLast24h(Integer transactionsLast24h) {
        this.transactionsLast24h = transactionsLast24h;
    }

    public Integer getChargebacksLast90d() {
        return chargebacksLast90d;
    }

    public void setChargebacksLast90d(Integer chargebacksLast90d) {
        this.chargebacksLast90d = chargebacksLast90d;
    }
}
