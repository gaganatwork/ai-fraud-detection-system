package com.gag.fraud.service;

import com.gag.fraud.dto.FraudAssessmentResponse;
import com.gag.fraud.dto.AssessmentHistoryResponse;
import com.gag.fraud.dto.TransactionRequest;
import com.gag.fraud.model.RiskLevel;
import com.gag.fraud.model.entity.FraudAssessmentRecord;
import com.gag.fraud.repository.FraudAssessmentRecordRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Service
public class FraudScoringService {

    private static final Set<String> HIGH_RISK_COUNTRIES = Set.of("NG", "PK", "RU", "UA");
    private final FraudAssessmentRecordRepository recordRepository;

    public FraudScoringService(FraudAssessmentRecordRepository recordRepository) {
        this.recordRepository = recordRepository;
    }

    public FraudAssessmentResponse assess(TransactionRequest request, String username) {
        List<String> reasons = new ArrayList<>();
        double score = 0.0;

        score += amountScore(request.getAmount(), reasons);
        score += velocityScore(request.getTransactionsLast24h(), reasons);
        score += accountAgeScore(request.getCustomerAccountAgeDays(), reasons);
        score += chargebackScore(request.getChargebacksLast90d(), reasons);
        score += locationScore(request.getCountry(), reasons);
        score += ipPatternScore(request.getIpAddress(), reasons);

        double normalized = Math.min(100.0, round(score));
        RiskLevel level = classify(normalized);
        boolean suspicious = level == RiskLevel.HIGH || normalized >= 65.0;

        FraudAssessmentResponse response = new FraudAssessmentResponse(
                request.getTransactionId(),
                normalized,
                level.name(),
                suspicious,
                reasons,
                recommendationFor(level)
        );

        recordRepository.save(new FraudAssessmentRecord(
                request.getTransactionId(),
                request.getCustomerId(),
                request.getAmount(),
                response.getRiskLevel(),
                response.getRiskScore(),
                response.isSuspicious(),
                username,
                Instant.now()
        ));

        return response;
    }

    public List<AssessmentHistoryResponse> getRecentHistory() {
        return recordRepository.findTop20ByOrderByCreatedAtDesc()
                .stream()
                .map(record -> new AssessmentHistoryResponse(
                        record.getTransactionId(),
                        record.getCustomerId(),
                        record.getRiskScore(),
                        record.getRiskLevel(),
                        record.isSuspicious(),
                        record.getCreatedBy(),
                        record.getCreatedAt()
                ))
                .toList();
    }

    private double amountScore(BigDecimal amount, List<String> reasons) {
        if (amount.compareTo(new BigDecimal("5000")) > 0) {
            reasons.add("High transaction amount");
            return 28.0;
        }
        if (amount.compareTo(new BigDecimal("2000")) > 0) {
            reasons.add("Moderately high transaction amount");
            return 16.0;
        }
        return 4.0;
    }

    private double velocityScore(int txLast24h, List<String> reasons) {
        if (txLast24h >= 20) {
            reasons.add("Unusual high transaction velocity");
            return 26.0;
        }
        if (txLast24h >= 10) {
            reasons.add("Elevated transaction velocity");
            return 14.0;
        }
        return 3.0;
    }

    private double accountAgeScore(int accountAgeDays, List<String> reasons) {
        if (accountAgeDays <= 7) {
            reasons.add("Very new customer account");
            return 18.0;
        }
        if (accountAgeDays <= 30) {
            reasons.add("New customer account");
            return 10.0;
        }
        return 2.0;
    }

    private double chargebackScore(int chargebacks, List<String> reasons) {
        if (chargebacks >= 3) {
            reasons.add("Multiple recent chargebacks");
            return 24.0;
        }
        if (chargebacks > 0) {
            reasons.add("Recent chargeback history");
            return 12.0;
        }
        return 0.0;
    }

    private double locationScore(String country, List<String> reasons) {
        if (HIGH_RISK_COUNTRIES.contains(country.toUpperCase())) {
            reasons.add("High-risk origin country");
            return 14.0;
        }
        return 2.0;
    }

    private double ipPatternScore(String ipAddress, List<String> reasons) {
        if (ipAddress.startsWith("10.") || ipAddress.startsWith("192.168.")) {
            reasons.add("Private network IP used in public transaction");
            return 9.0;
        }
        return 1.0;
    }

    private RiskLevel classify(double score) {
        if (score >= 70.0) {
            return RiskLevel.HIGH;
        }
        if (score >= 40.0) {
            return RiskLevel.MEDIUM;
        }
        return RiskLevel.LOW;
    }

    private String recommendationFor(RiskLevel level) {
        return switch (level) {
            case HIGH -> "Block transaction and trigger manual review immediately.";
            case MEDIUM -> "Request step-up authentication before approval.";
            case LOW -> "Approve transaction with routine monitoring.";
        };
    }

    private double round(double score) {
        return BigDecimal.valueOf(score).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }
}
