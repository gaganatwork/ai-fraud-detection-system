package com.gag.fraud.controller;

import com.gag.fraud.dto.AssessmentHistoryResponse;
import com.gag.fraud.dto.FraudAssessmentResponse;
import com.gag.fraud.dto.TransactionRequest;
import com.gag.fraud.service.FraudScoringService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/fraud")
public class FraudDetectionController {

    private final FraudScoringService fraudScoringService;

    public FraudDetectionController(FraudScoringService fraudScoringService) {
        this.fraudScoringService = fraudScoringService;
    }

    @PostMapping("/assess")
    @PreAuthorize("hasAnyRole('ADMIN','ANALYST')")
    public ResponseEntity<FraudAssessmentResponse> assess(@Valid @RequestBody TransactionRequest request,
                                                          Authentication authentication) {
        return ResponseEntity.ok(fraudScoringService.assess(request, authentication.getName()));
    }

    @GetMapping("/history")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<AssessmentHistoryResponse>> history() {
        return ResponseEntity.ok(fraudScoringService.getRecentHistory());
    }
}
