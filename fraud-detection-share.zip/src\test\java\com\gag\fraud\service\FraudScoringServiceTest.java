package com.gag.fraud.service;

import com.gag.fraud.dto.FraudAssessmentResponse;
import com.gag.fraud.dto.TransactionRequest;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.gag.fraud.model.entity.FraudAssessmentRecord;
import com.gag.fraud.repository.FraudAssessmentRecordRepository;

class FraudScoringServiceTest {

    private final FraudAssessmentRecordRepository repository = mock(FraudAssessmentRecordRepository.class);
    private final FraudScoringService service = new FraudScoringService(repository);

    FraudScoringServiceTest() {
        when(repository.save(any(FraudAssessmentRecord.class))).thenAnswer(invocation -> invocation.getArgument(0));
    }

    @Test
    void shouldClassifyHighRiskTransaction() {
        TransactionRequest request = baseRequest();
        request.setAmount(new BigDecimal("9000"));
        request.setTransactionsLast24h(30);
        request.setCustomerAccountAgeDays(2);
        request.setChargebacksLast90d(4);
        request.setCountry("NG");

        FraudAssessmentResponse response = service.assess(request, "analyst");

        assertEquals("HIGH", response.getRiskLevel());
        assertTrue(response.isSuspicious());
    }

    @Test
    void shouldClassifyLowRiskTransaction() {
        TransactionRequest request = baseRequest();
        request.setAmount(new BigDecimal("45.50"));
        request.setTransactionsLast24h(1);
        request.setCustomerAccountAgeDays(500);
        request.setChargebacksLast90d(0);
        request.setCountry("IN");
        request.setIpAddress("8.8.8.8");

        FraudAssessmentResponse response = service.assess(request, "analyst");

        assertEquals("LOW", response.getRiskLevel());
    }

    private TransactionRequest baseRequest() {
        TransactionRequest request = new TransactionRequest();
        request.setTransactionId("TXN-1");
        request.setCustomerId("CUST-1");
        request.setAmount(new BigDecimal("10"));
        request.setCurrency("INR");
        request.setCountry("IN");
        request.setDeviceId("DVC-1");
        request.setIpAddress("192.168.1.23");
        request.setCustomerAccountAgeDays(10);
        request.setTransactionsLast24h(5);
        request.setChargebacksLast90d(0);
        return request;
    }
}
