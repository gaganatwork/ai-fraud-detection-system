package com.gag.fraud.config;

import com.gag.fraud.model.entity.Role;
import com.gag.fraud.model.entity.UserAccount;
import com.gag.fraud.repository.UserAccountRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner seedUsers(UserAccountRepository userAccountRepository, PasswordEncoder passwordEncoder) {
        return args -> {
            if (userAccountRepository.findByUsername("admin").isEmpty()) {
                userAccountRepository.save(new UserAccount("admin", passwordEncoder.encode("admin123"), Role.ROLE_ADMIN));
            }
            if (userAccountRepository.findByUsername("analyst").isEmpty()) {
                userAccountRepository.save(new UserAccount("analyst", passwordEncoder.encode("analyst123"), Role.ROLE_ANALYST));
            }
        };
    }
}
