package com.gag.fraud.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "fraud_assessments")
public class FraudAssessmentRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 60)
    private String transactionId;

    @Column(nullable = false, length = 80)
    private String customerId;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(nullable = false, length = 10)
    private String riskLevel;

    @Column(nullable = false)
    private double riskScore;

    @Column(nullable = false)
    private boolean suspicious;

    @Column(nullable = false, length = 120)
    private String createdBy;

    @Column(nullable = false)
    private Instant createdAt;

    protected FraudAssessmentRecord() {
    }

    public FraudAssessmentRecord(String transactionId,
                                 String customerId,
                                 BigDecimal amount,
                                 String riskLevel,
                                 double riskScore,
                                 boolean suspicious,
                                 String createdBy,
                                 Instant createdAt) {
        this.transactionId = transactionId;
        this.customerId = customerId;
        this.amount = amount;
        this.riskLevel = riskLevel;
        this.riskScore = riskScore;
        this.suspicious = suspicious;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public double getRiskScore() {
        return riskScore;
    }

    public boolean isSuspicious() {
        return suspicious;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
