package com.gag.fraud.model.entity;

public enum Role {
    ROLE_ADMIN,
    ROLE_ANALYST
}
