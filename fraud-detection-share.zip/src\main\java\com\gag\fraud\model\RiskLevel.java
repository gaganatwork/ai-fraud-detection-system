package com.gag.fraud.model;

public enum RiskLevel {
    LOW,
    MEDIUM,
    HIGH
}
