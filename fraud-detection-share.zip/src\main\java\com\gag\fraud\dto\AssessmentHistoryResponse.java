package com.gag.fraud.dto;

import java.time.Instant;

public class AssessmentHistoryResponse {

    private String transactionId;
    private String customerId;
    private double riskScore;
    private String riskLevel;
    private boolean suspicious;
    private String createdBy;
    private Instant createdAt;

    public AssessmentHistoryResponse(String transactionId,
                                     String customerId,
                                     double riskScore,
                                     String riskLevel,
                                     boolean suspicious,
                                     String createdBy,
                                     Instant createdAt) {
        this.transactionId = transactionId;
        this.customerId = customerId;
        this.riskScore = riskScore;
        this.riskLevel = riskLevel;
        this.suspicious = suspicious;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public double getRiskScore() {
        return riskScore;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public boolean isSuspicious() {
        return suspicious;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
