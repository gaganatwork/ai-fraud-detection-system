package com.gag.fraud.repository;

import com.gag.fraud.model.entity.FraudAssessmentRecord;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FraudAssessmentRecordRepository extends JpaRepository<FraudAssessmentRecord, Long> {
    List<FraudAssessmentRecord> findTop20ByOrderByCreatedAtDesc();
}
