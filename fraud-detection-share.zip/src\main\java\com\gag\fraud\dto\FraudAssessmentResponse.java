package com.gag.fraud.dto;

import java.util.List;

public class FraudAssessmentResponse {

    private String transactionId;
    private double riskScore;
    private String riskLevel;
    private boolean suspicious;
    private List<String> triggeredRules;
    private String recommendation;

    public FraudAssessmentResponse() {
    }

    public FraudAssessmentResponse(String transactionId,
                                   double riskScore,
                                   String riskLevel,
                                   boolean suspicious,
                                   List<String> triggeredRules,
                                   String recommendation) {
        this.transactionId = transactionId;
        this.riskScore = riskScore;
        this.riskLevel = riskLevel;
        this.suspicious = suspicious;
        this.triggeredRules = triggeredRules;
        this.recommendation = recommendation;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public double getRiskScore() {
        return riskScore;
    }

    public void setRiskScore(double riskScore) {
        this.riskScore = riskScore;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }

    public boolean isSuspicious() {
        return suspicious;
    }

    public void setSuspicious(boolean suspicious) {
        this.suspicious = suspicious;
    }

    public List<String> getTriggeredRules() {
        return triggeredRules;
    }

    public void setTriggeredRules(List<String> triggeredRules) {
        this.triggeredRules = triggeredRules;
    }

    public String getRecommendation() {
        return recommendation;
    }

    public void setRecommendation(String recommendation) {
        this.recommendation = recommendation;
    }
}
